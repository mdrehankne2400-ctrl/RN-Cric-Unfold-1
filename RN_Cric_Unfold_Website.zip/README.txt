RN Cric Unfold Website
1. Keep index.html and hero.png in the same folder.
2. Open index.html in Chrome to preview the website.
3. To publish it, upload both files to any web hosting service.
4. The Live Score section is currently a demo; a real score API can be connected later.
